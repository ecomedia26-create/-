import { motion, AnimatePresence } from "motion/react";
import ReactMarkdown from "react-markdown";
import { 
  BookOpen, 
  Sparkles, 
  RotateCcw, 
  Volume2, 
  SquareSquare, 
  Printer, 
  Copy, 
  BookmarkPlus,
  Play,
  Pause,
  Loader2,
  ChevronRight,
  ChevronLeft,
  VolumeX,
  Sparkle
} from "lucide-react";
import { useState, useEffect, useRef } from "react";

interface StoryViewProps {
  story: string;
  onReset: () => void;
  imageUrl?: string | null;
}

const AI_VOICES = [
  { id: "Kore", name: "קורי 👧", gender: "female", description: "נשי, שמח ובהיר, מושלם לסיפורים" },
  { id: "Puck", name: "פאק 👦", gender: "male", description: "גברי צעיר, קופצני וחברותי מאוד" },
  { id: "Zephyr", name: "זפיר 🧘‍♀️", gender: "female", description: "נשי עדין, רגוע ומלטף – נפלא לשינה" },
  { id: "Fenrir", name: "פנריר 🪵", gender: "male", description: "גברי חם, עוטף ונעים מאוד להקשבה" },
  { id: "Charon", name: "כארון 🧔", gender: "male", description: "גברי עמוק ומלכותי, מעולה להרפתקאות" }
];

export function StoryView({ story, onReset, imageUrl }: StoryViewProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentParagraphIndex, setCurrentParagraphIndex] = useState(0);
  const [useAiVoice, setUseAiVoice] = useState(true);
  const [selectedAiVoice, setSelectedAiVoice] = useState("Kore");
  const [audioLoading, setAudioLoading] = useState(false);
  const [isSaved, setIsSaved] = useState(false);

  // Local voices (fallback)
  const [localVoices, setLocalVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [selectedLocalVoice, setSelectedLocalVoice] = useState<SpeechSynthesisVoice | null>(null);

  const [audioSource, setAudioSource] = useState<AudioBufferSourceNode | null>(null);
  const [audioCtx, setAudioCtx] = useState<AudioContext | null>(null);

  const isPlayingRef = useRef(false);
  const currentParagraphIndexRef = useRef(0);
  const audioSourceRef = useRef<AudioBufferSourceNode | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);

  const paragraphs = story.split(/\n\n+/).filter(p => p.trim() !== "");

  useEffect(() => {
    isPlayingRef.current = isPlaying;
  }, [isPlaying]);

  useEffect(() => {
    currentParagraphIndexRef.current = currentParagraphIndex;
  }, [currentParagraphIndex]);

  useEffect(() => {
    audioSourceRef.current = audioSource;
  }, [audioSource]);

  useEffect(() => {
    audioCtxRef.current = audioCtx;
  }, [audioCtx]);

  useEffect(() => {
    const loadVoices = () => {
      const availableVoices = window.speechSynthesis.getVoices();
      const hebrewVoices = availableVoices.filter(v => v.lang.startsWith('he'));
      setLocalVoices(hebrewVoices);
      if (hebrewVoices.length > 0 && !selectedLocalVoice) {
        setSelectedLocalVoice(hebrewVoices[0]);
      }
    };

    loadVoices();
    window.speechSynthesis.onvoiceschanged = loadVoices;

    return () => {
      window.speechSynthesis.onvoiceschanged = null;
      window.speechSynthesis.cancel();
      stopAudioPlayback();
    };
  }, []);

  const stopAudioPlayback = () => {
    if (audioSourceRef.current) {
      try {
        audioSourceRef.current.onended = null;
        audioSourceRef.current.stop();
      } catch (e) {}
      setAudioSource(null);
    }
    if (audioCtxRef.current) {
      try {
        audioCtxRef.current.close();
      } catch (e) {}
      setAudioCtx(null);
    }
  };

  const playAudioChunk = (base64Data: string, onEnded: () => void) => {
    try {
      stopAudioPlayback();
      
      const binaryString = window.atob(base64Data);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      
      const int16Data = new Int16Array(bytes.buffer);
      
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      setAudioCtx(ctx);
      
      const audioBuffer = ctx.createBuffer(1, int16Data.length, 24000);
      const channelData = audioBuffer.getChannelData(0);
      
      for (let i = 0; i < int16Data.length; i++) {
        channelData[i] = int16Data[i] / 32768.0;
      }
      
      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(ctx.destination);
      
      source.onended = () => {
        onEnded();
      };
      
      source.start(0);
      setAudioSource(source);
    } catch (err) {
      console.error("Error playing raw audio PCM chunk:", err);
      onEnded();
    }
  };

  const playParagraph = async (index: number) => {
    if (index >= paragraphs.length) {
      setIsPlaying(false);
      setCurrentParagraphIndex(0);
      return;
    }

    setCurrentParagraphIndex(index);
    const textToRead = paragraphs[index]
      .replace(/[#_*\[\]`\-()]/g, '')
      .trim();

    if (!textToRead) {
      playParagraph(index + 1);
      return;
    }

    if (useAiVoice) {
      setAudioLoading(true);
      try {
        const response = await fetch("/api/tts", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ text: textToRead, voice: selectedAiVoice }),
        });

        if (!response.ok) {
          throw new Error("TTS API error");
        }

        const data = await response.json();
        setAudioLoading(false);

        if (!isPlayingRef.current) return;

        playAudioChunk(data.audio, () => {
          setTimeout(() => {
            if (isPlayingRef.current && currentParagraphIndexRef.current === index) {
              playParagraph(index + 1);
            }
          }, 600);
        });
      } catch (err) {
        console.error("AI TTS failed, falling back to local speech:", err);
        setAudioLoading(false);
        playLocalParagraph(textToRead, index);
      }
    } else {
      playLocalParagraph(textToRead, index);
    }
  };

  const playLocalParagraph = (textToRead: string, index: number) => {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(textToRead);
    utterance.lang = 'he-IL';
    if (selectedLocalVoice) {
      utterance.voice = selectedLocalVoice;
    }
    utterance.rate = 0.95;
    utterance.onend = () => {
      setTimeout(() => {
        if (isPlayingRef.current && currentParagraphIndexRef.current === index) {
          playParagraph(index + 1);
        }
      }, 400);
    };
    utterance.onerror = () => {
      if (isPlayingRef.current && currentParagraphIndexRef.current === index) {
        playParagraph(index + 1);
      }
    };
    window.speechSynthesis.speak(utterance);
  };

  const handleTogglePlay = () => {
    if (isPlaying) {
      setIsPlaying(false);
      window.speechSynthesis.pause();
      stopAudioPlayback();
    } else {
      setIsPlaying(true);
      isPlayingRef.current = true;
      
      if (useAiVoice) {
        playParagraph(currentParagraphIndex);
      } else {
        if (window.speechSynthesis.paused) {
          window.speechSynthesis.resume();
        } else {
          playParagraph(currentParagraphIndex);
        }
      }
    }
  };

  const handleStop = () => {
    setIsPlaying(false);
    isPlayingRef.current = false;
    window.speechSynthesis.cancel();
    stopAudioPlayback();
    setCurrentParagraphIndex(0);
  };

  const handleNext = () => {
    const nextIndex = currentParagraphIndex + 1;
    if (nextIndex < paragraphs.length) {
      window.speechSynthesis.cancel();
      stopAudioPlayback();
      if (isPlaying) {
        playParagraph(nextIndex);
      } else {
        setCurrentParagraphIndex(nextIndex);
      }
    }
  };

  const handlePrev = () => {
    const prevIndex = currentParagraphIndex - 1;
    if (prevIndex >= 0) {
      window.speechSynthesis.cancel();
      stopAudioPlayback();
      if (isPlaying) {
        playParagraph(prevIndex);
      } else {
        setCurrentParagraphIndex(prevIndex);
      }
    }
  };

  const handleAiVoiceChange = (voiceId: string) => {
    setSelectedAiVoice(voiceId);
    if (isPlaying) {
      window.speechSynthesis.cancel();
      stopAudioPlayback();
      setTimeout(() => {
        playParagraph(currentParagraphIndex);
      }, 200);
    }
  };

  const handleVoiceTypeChange = (isAi: boolean) => {
    setUseAiVoice(isAi);
    if (isPlaying) {
      window.speechSynthesis.cancel();
      stopAudioPlayback();
      setTimeout(() => {
        playParagraph(currentParagraphIndex);
      }, 200);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(story);
    alert("הסיפור הועתק ללוח!");
  };

  const handleSave = () => {
    const saved = JSON.parse(localStorage.getItem("savedStories") || "[]");
    saved.push({ id: Date.now(), content: story, title: "סיפור קסום חדש" });
    localStorage.setItem("savedStories", JSON.stringify(saved));
    setIsSaved(true);
    alert("הסיפור נשמר בהצלחה!");
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95, y: 20 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      transition={{ type: "spring", damping: 25, stiffness: 200 }}
      className="relative max-w-4xl mx-auto"
    >
      {/* Decorative background elements */}
      <div className="absolute -inset-4 bg-gradient-to-r from-pink-300 via-purple-300 to-indigo-300 rounded-[3rem] blur-xl opacity-50 z-0" />
      
      <div className="relative z-10 bg-white/95 backdrop-blur-2xl rounded-[2.5rem] shadow-2xl overflow-hidden border-2 border-white/50">
        {/* Header Ribbon */}
        <div className="bg-gradient-to-r from-purple-600 to-pink-500 py-6 px-8 text-center relative overflow-hidden">
          <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] opacity-30 mix-blend-overlay" />
          <h2 className="text-3xl sm:text-4xl font-black text-white drop-shadow-md flex items-center justify-center gap-3 relative z-10">
            <Sparkles className="text-yellow-300 w-8 h-8 animate-pulse" />
            הסיפור הקסום שלך
            <Sparkles className="text-yellow-300 w-8 h-8 animate-pulse" />
          </h2>
        </div>

        {/* Audio Box Panel */}
        <div className="m-6 p-6 bg-gradient-to-br from-purple-50/50 via-pink-50/30 to-indigo-50/50 rounded-3xl border-2 border-purple-100 shadow-sm">
          <h3 className="text-lg font-black text-purple-900 mb-4 flex items-center gap-2">
            <Volume2 className="w-5 h-5 text-purple-600" />
            <span>תיבת השמע הקסומה 🪄</span>
          </h3>

          {/* Voice Type Switcher */}
          <div className="flex bg-purple-100/50 p-1 rounded-2xl w-fit mb-6">
            <button
              onClick={() => handleVoiceTypeChange(true)}
              className={`px-4 py-2 rounded-xl font-bold text-sm transition-all ${
                useAiVoice 
                  ? "bg-white text-purple-700 shadow-sm" 
                  : "text-purple-600/70 hover:text-purple-700"
              }`}
            >
              ✨ קול בינה מלאכותית (מומלץ)
            </button>
            <button
              onClick={() => handleVoiceTypeChange(false)}
              className={`px-4 py-2 rounded-xl font-bold text-sm transition-all ${
                !useAiVoice 
                  ? "bg-white text-purple-700 shadow-sm" 
                  : "text-purple-600/70 hover:text-purple-700"
              }`}
            >
              🌐 קול מערכת מקומי
            </button>
          </div>

          {/* Voice Character Cards Grid */}
          {useAiVoice ? (
            <div className="mb-6">
              <label className="block text-sm font-bold text-purple-800/80 mb-3">בחרו מספר סיפור קסום:</label>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-3">
                {AI_VOICES.map((v) => {
                  const isSelected = selectedAiVoice === v.id;
                  return (
                    <button
                      key={v.id}
                      onClick={() => handleAiVoiceChange(v.id)}
                      className={`flex flex-col items-center text-center p-3 rounded-2xl transition-all border-2 cursor-pointer ${
                        isSelected
                          ? "bg-purple-100/60 border-purple-500 shadow-md ring-2 ring-purple-200/50 scale-[1.02]"
                          : "bg-white/80 border-purple-100 hover:border-purple-300 hover:bg-white"
                      }`}
                    >
                      <span className="text-3xl mb-1">{v.id === "Kore" ? "👧" : v.id === "Puck" ? "👦" : v.id === "Zephyr" ? "🧘‍♀️" : v.id === "Fenrir" ? "🪵" : "🧔"}</span>
                      <span className="font-bold text-purple-950 text-sm mb-1">{v.name}</span>
                      <span className="text-xs text-purple-700/70 leading-snug">{v.description}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          ) : (
            <div className="mb-6">
              <label className="block text-sm font-bold text-purple-800/80 mb-2">בחרו קול מקומי מהמערכת:</label>
              {localVoices.length > 0 ? (
                <div className="relative max-w-xs">
                  <select
                    className="appearance-none w-full bg-white border-2 border-purple-200 text-purple-700 font-bold py-2.5 pl-10 pr-4 rounded-xl shadow-sm focus:outline-none focus:border-purple-400 cursor-pointer text-sm"
                    value={selectedLocalVoice?.name || ''}
                    onChange={(e) => {
                      const voice = localVoices.find(v => v.name === e.target.value);
                      if (voice) {
                        setSelectedLocalVoice(voice);
                        if (isPlaying) {
                          window.speechSynthesis.cancel();
                          setTimeout(() => playParagraph(currentParagraphIndex), 200);
                        }
                      }
                    }}
                  >
                    {localVoices.map((voice) => (
                      <option key={voice.name} value={voice.name}>
                        {voice.name}
                      </option>
                    ))}
                  </select>
                  <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center px-3 text-purple-700">
                    <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                      <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/>
                    </svg>
                  </div>
                </div>
              ) : (
                <p className="text-xs text-amber-600 bg-amber-50 p-3 rounded-xl border border-amber-200">
                  לא נמצאו קולות בעברית על גבי המכשיר שלך. מומלץ להשתמש בקול בינה מלאכותית ✨
                </p>
              )}
            </div>
          )}

          {/* Audio Playback Controls */}
          <div className="flex flex-col sm:flex-row items-center gap-4 justify-between pt-2 border-t border-purple-100">
            {/* Play, Stop, Next/Prev Buttons */}
            <div className="flex items-center gap-3">
              <button
                onClick={handlePrev}
                disabled={currentParagraphIndex === 0}
                className="p-3 bg-white hover:bg-purple-50 disabled:opacity-40 rounded-full border-2 border-purple-200 shadow-sm transition-all disabled:pointer-events-none"
                title="פסקה קודמת"
              >
                <ChevronRight className="w-5 h-5 text-purple-700" />
              </button>

              <button
                onClick={handleTogglePlay}
                disabled={audioLoading}
                className={`flex items-center gap-2 px-8 py-3.5 rounded-full font-black text-lg transition-all shadow-md active:scale-95 ${
                  isPlaying
                    ? "bg-pink-500 hover:bg-pink-600 text-white shadow-pink-200"
                    : "bg-purple-600 hover:bg-purple-700 text-white shadow-purple-200"
                }`}
              >
                {audioLoading ? (
                  <>
                    <Loader2 className="w-6 h-6 animate-spin" />
                    <span>הקסם מתכונן...</span>
                  </>
                ) : isPlaying ? (
                  <>
                    <Pause className="w-6 h-6 fill-white" />
                    <span>השהה הקראה</span>
                  </>
                ) : (
                  <>
                    <Play className="w-6 h-6 fill-white" />
                    <span>הקרא סיפור ✨</span>
                  </>
                )}
              </button>

              <button
                onClick={handleStop}
                disabled={!isPlaying && currentParagraphIndex === 0}
                className="p-3 bg-white hover:bg-red-50 text-red-600 border-2 border-red-200 shadow-sm rounded-full transition-all disabled:opacity-40 disabled:pointer-events-none"
                title="עצור והתחל מחדש"
              >
                <SquareSquare className="w-5 h-5" />
              </button>

              <button
                onClick={handleNext}
                disabled={currentParagraphIndex === paragraphs.length - 1}
                className="p-3 bg-white hover:bg-purple-50 disabled:opacity-40 rounded-full border-2 border-purple-200 shadow-sm transition-all disabled:pointer-events-none"
                title="פסקה הבאה"
              >
                <ChevronLeft className="w-5 h-5 text-purple-700" />
              </button>
            </div>

            {/* Reading Status & Progress Indicator */}
            <div className="flex items-center gap-3 text-sm text-purple-900 font-bold">
              {isPlaying && (
                <div className="flex gap-1 items-end h-4">
                  <span className="w-1 bg-purple-500 rounded-full animate-[bounce_1s_infinite_100ms] h-3" />
                  <span className="w-1 bg-pink-500 rounded-full animate-[bounce_1s_infinite_300ms] h-4" />
                  <span className="w-1 bg-purple-500 rounded-full animate-[bounce_1s_infinite_500ms] h-2" />
                  <span className="w-1 bg-pink-500 rounded-full animate-[bounce_1s_infinite_200ms] h-3" />
                </div>
              )}
              <span className="bg-purple-100 text-purple-800 px-3 py-1 rounded-full text-xs">
                פסקה {currentParagraphIndex + 1} מתוך {paragraphs.length}
              </span>
            </div>
          </div>
        </div>

        {/* Story Content with Paragraph Highlighting */}
        <div className="px-8 pb-8 pt-4 sm:px-12 sm:pb-12 md:px-16 md:pb-16 relative">
          {imageUrl && (
            <div className="mb-10 rounded-[2rem] overflow-hidden border-8 border-white shadow-xl max-w-3xl mx-auto rotate-1 hover:rotate-0 transition-transform duration-500 bg-purple-50">
              <img src={imageUrl} alt="איור הסיפור" className="w-full h-auto object-cover" referrerPolicy="no-referrer" />
            </div>
          )}
          <div className="absolute top-10 right-10 opacity-5 text-purple-900 pointer-events-none">
            <BookOpen className="w-48 h-48" />
          </div>
          
          <div className="prose prose-purple prose-lg sm:prose-xl mx-auto text-purple-950 font-medium leading-relaxed prose-headings:font-black prose-headings:text-purple-800 prose-strong:text-purple-700 prose-strong:font-bold prose-p:mb-0 space-y-6" dir="rtl">
            {paragraphs.map((paraText, idx) => {
              const isActive = idx === currentParagraphIndex;
              return (
                <motion.div
                  key={idx}
                  animate={{ 
                    scale: isActive && isPlaying ? 1.01 : 1,
                    backgroundColor: isActive && isPlaying ? "rgba(243, 232, 255, 0.4)" : "rgba(255, 255, 255, 0)"
                  }}
                  transition={{ duration: 0.3 }}
                  className={`p-4 rounded-2xl border-r-4 transition-all ${
                    isActive && isPlaying
                      ? "border-purple-500 shadow-sm ring-1 ring-purple-100"
                      : "border-transparent"
                  }`}
                >
                  <ReactMarkdown>{paraText}</ReactMarkdown>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Footer actions */}
        <div className="bg-purple-50/50 p-6 sm:p-8 flex flex-col sm:flex-row justify-center items-center gap-4 border-t border-purple-100">
          <button
            onClick={() => {
              window.speechSynthesis.cancel();
              stopAudioPlayback();
              onReset();
            }}
            className="flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-purple-600 to-pink-500 text-white font-bold rounded-2xl shadow-sm border-2 border-transparent hover:shadow-md transition-all active:scale-95 group w-full sm:w-auto justify-center cursor-pointer"
          >
            <RotateCcw className="w-5 h-5 group-hover:-rotate-180 transition-transform duration-500" />
            <span className="text-lg">צור סיפור חדש</span>
          </button>
          
          <div className="flex gap-2 w-full sm:w-auto justify-center">
            <button
              onClick={handleSave}
              disabled={isSaved}
              className={`flex items-center justify-center p-4 rounded-2xl border-2 transition-all shadow-sm flex-1 sm:flex-none cursor-pointer ${isSaved ? 'bg-green-50 text-green-600 border-green-200 cursor-default' : 'bg-white text-purple-600 border-purple-200 hover:bg-purple-50 hover:border-purple-300'}`}
              title="שמור סיפור"
            >
              <BookmarkPlus className="w-6 h-6" />
            </button>
            <button
              onClick={handleCopy}
              className="flex items-center justify-center p-4 bg-white text-purple-600 border-2 border-purple-200 hover:bg-purple-50 hover:border-purple-300 rounded-2xl shadow-sm transition-all flex-1 sm:flex-none cursor-pointer"
              title="העתק טקסט"
            >
              <Copy className="w-6 h-6" />
            </button>
            <button
              onClick={handlePrint}
              className="flex items-center justify-center p-4 bg-white text-purple-600 border-2 border-purple-200 hover:bg-purple-50 hover:border-purple-300 rounded-2xl shadow-sm transition-all flex-1 sm:flex-none cursor-pointer"
              title="הדפס סיפור"
            >
              <Printer className="w-6 h-6" />
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
