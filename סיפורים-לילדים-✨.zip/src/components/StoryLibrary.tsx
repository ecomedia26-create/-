import { motion } from "motion/react";
import { Heart, BookOpen, Trash2 } from "lucide-react";
import { useState, useEffect } from "react";
import ReactMarkdown from "react-markdown";

const STORIES = [
  {
    id: "zigi",
    title: "בקצב של זיגי",
    value: "קבלת השונה",
    summary: "סיפור על דבורה שמזמזמת בקצב שונה, ואיך הייחודיות שלנו עושה את העולם צבעוני יותר.",
    youtubeId: "WjjUud9EF84"
  },
  {
    id: "peleg",
    title: "האבן של פלג",
    value: "סליחה ושחרור כעסים",
    summary: "פלג הבונה לומד שכאשר סולחים, הלב הופך קל ומשוחרר ממשא כבד ומעיק.",
    youtubeId: "4qEZR740UF8"
  },
  {
    id: "maya",
    title: "מאיה והזינוק הגדול",
    value: "אומץ והתגברות",
    summary: "פילה שמפחדת לקפוץ, מוצאת בתוכה את האומץ לעשות זאת כדי להציל גור אריות.",
    youtubeId: "RBVjr9BDoO8"
  },
  {
    id: "nevo",
    title: "האגוז של נבו",
    value: "נתינה טהורה",
    summary: "עכבר שדה מוותר על ארוחת מלכים למען קיפוד זקן, ומגלה את שמחת הנתינה בסתר.",
    youtubeId: "emNciSG4P70"
  },
  {
    id: "ayala",
    title: "איילה בלב העמק",
    value: "סבלנות והמתנה",
    summary: "איילה צעירה לומדת שלכל דבר בטבע יש את הזמן המדויק שלו, וששווה לחכות.",
    youtubeId: "Hcdd3LUyk50"
  },
  {
    id: "rimona",
    title: "רימונה הכבשה",
    value: "הצבת גבולות",
    summary: "כבשה שלומדת שמותר וצריך להקשיב ללב, ולא חייבים להסכים לדברים שפוגעים בה.",
    youtubeId: "Q9X5uRXGuFE"
  },
  {
    id: "trees",
    title: "השלום בין העצים",
    value: "שיתוף ואחדות",
    summary: "העצים ביער מבינים שכולם יכולים לגדול ולפרוח יחד כשהם חולקים את אור השמש.",
    youtubeId: "Y-YCMngueXY"
  },
  {
    id: "kelev",
    title: "כ-לב",
    value: "חיבור ללב וחברות",
    summary: "סיפור מרגש על החיבור העמוק ללב, חברות אמת והיכולת להקשיב למה שקורה בפנים.",
    youtubeId: "AGQ8ZmN9F3s"
  },
  {
    id: "beito_shel_adam",
    title: "ביתו של אדם",
    value: "שייכות והודיה",
    summary: "על החיפוש אחר המקום הבטוח והחם שלנו בעולם, וההבנה שהבית האמיתי נמצא בתוכנו.",
    youtubeId: "TJZ5czfYYxY"
  },
  {
    id: "baal_shem_tov",
    title: "הבעל שם טוב והתלמיד הצמא",
    value: "אמונה והשגחה",
    summary: "סיפור חסידי נפלא המלמד על כוחה של אמונה תמימה, השגחה פרטית והצמא לרוחניות.",
    youtubeId: "9ycYaZRnTcc"
  },
  {
    id: "lihyot_misheu_aher",
    title: "להיות מישהו אחר",
    value: "אהבה עצמית וקבלה",
    summary: "סיפור קסום על החלום להיות מישהו אחר, המגלה לנו כמה מיוחד וחשוב להיות פשוט מי שאנחנו.",
    youtubeId: "XqVdKs962Q8"
  },
  {
    id: "lev_boer",
    title: "אם הלב בוער אז צועקים",
    value: "הקשבה ואומץ פנימי",
    summary: "סיפור מעורר השראה המלמד אותנו להקשיב לקול הלב הבוער בתוכנו, להביע את עצמנו באומץ ולפעול מתוך אמת פנימית.",
    youtubeId: "uavaISVZTS8"
  },
  {
    id: "emuna_yeshua",
    title: "עם מעט תשוקה והרבה אמונה הישועה שלך בדרך",
    value: "אמונה ותקווה",
    summary: "מסר מרומם ומלא מוטיבציה המזכיר לנו שאמונה שלמה בשילוב עם להבת התשוקה סוללת לנו את הדרך לניסים וישועות.",
    youtubeId: "J1-JGNA2zR8"
  },
  {
    id: "memshelet_shalom",
    title: "ממשלת שלום",
    value: "שלום פנימי והרמוניה",
    summary: "סיפור קסום שמחבר אותנו למקום השקט והשלם בתוכנו, ומזכיר לנו שהשלום האמיתי מתחיל מבפנים ומקרין החוצה.",
    youtubeId: "6YVbBGQyFKU"
  },
  {
    id: "neval_asor",
    title: "נבל עשור",
    value: "הודיה ושמחה פנימית",
    summary: "מסר מרגש ועוצמתי על כוחה של ההודיה, ניגון הלב והיכולת למצוא את השמחה והאור גם ברגעים פשוטים.",
    youtubeId: "jZcqxLY8kNQ"
  }
];

interface SavedStory {
  id: number;
  title: string;
  content: string;
}

export function StoryLibrary() {
  const [savedStories, setSavedStories] = useState<SavedStory[]>([]);
  const [expandedStory, setExpandedStory] = useState<number | null>(null);

  useEffect(() => {
    const loadSaved = () => {
      const saved = JSON.parse(localStorage.getItem("savedStories") || "[]");
      setSavedStories(saved);
    };
    loadSaved();
    // Listen for storage changes from other tabs or same tab
    window.addEventListener("storage", loadSaved);
    return () => window.removeEventListener("storage", loadSaved);
  }, []);

  const deleteStory = (id: number) => {
    const newStories = savedStories.filter(s => s.id !== id);
    setSavedStories(newStories);
    localStorage.setItem("savedStories", JSON.stringify(newStories));
  };

  return (
    <div className="flex flex-col gap-12 pb-12">
      {savedStories.length > 0 && (
        <div>
          <h3 className="text-2xl font-black text-purple-900 mb-6 flex items-center gap-2">
            <BookOpen className="w-6 h-6 text-pink-500" />
            הסיפורים השמורים שלי
          </h3>
          <div className="flex flex-wrap justify-center gap-6">
            {savedStories.map((story, i) => (
              <motion.div
                key={story.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="w-full md:w-[calc(50%-0.75rem)] bg-white/80 backdrop-blur-xl rounded-3xl overflow-hidden shadow-sm border border-purple-100 flex flex-col hover:shadow-lg transition-shadow p-6"
              >
                <div className="flex justify-between items-start mb-4 border-b border-purple-100 pb-4">
                  <h4 className="text-xl font-bold text-purple-900">{story.title}</h4>
                  <button 
                    onClick={() => deleteStory(story.id)}
                    className="p-2 text-red-400 hover:text-red-600 hover:bg-red-50 rounded-full transition-colors"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
                
                <div className={`prose prose-purple prose-sm sm:prose-base font-medium text-purple-900 ${expandedStory === story.id ? '' : 'line-clamp-6'} transition-all`} dir="rtl">
                  <ReactMarkdown>{story.content}</ReactMarkdown>
                </div>
                
                <button 
                  onClick={() => setExpandedStory(expandedStory === story.id ? null : story.id)}
                  className="mt-4 text-purple-600 font-bold hover:text-pink-600 transition-colors text-sm border-t border-purple-50 pt-4"
                >
                  {expandedStory === story.id ? "הסתר סיפור" : "קרא סיפור מלא..."}
                </button>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      <div>
        <h3 className="text-xl font-black text-purple-900 mb-4 flex items-center gap-2">
          <Heart className="w-5 h-5 text-pink-500 animate-pulse" />
          סיפורים מקוריים ומסרים מעוררי השראה
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {STORIES.map((story, i) => (
            <motion.div
              key={story.id}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.04 }}
              className="bg-white/90 backdrop-blur-md rounded-2xl overflow-hidden shadow-sm border border-purple-100 flex flex-col hover:shadow-md hover:-translate-y-1 transition-all duration-300"
            >
              <div className="p-2 pb-0">
                <div className="aspect-video w-full bg-purple-950 rounded-xl overflow-hidden shadow-inner relative">
                  <iframe
                    className="w-full h-full"
                    src={`https://www.youtube.com/embed/${story.youtubeId}`}
                    title={story.title}
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  ></iframe>
                </div>
              </div>
              <div className="p-3.5 flex flex-col flex-grow">
                <div className="flex items-start justify-between mb-2 gap-1.5 flex-wrap">
                  <h4 className="text-sm font-black text-purple-900 leading-tight">{story.title}</h4>
                  <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-full bg-pink-50 text-pink-600 text-[10px] font-bold shrink-0">
                    <Heart className="w-2.5 h-2.5" />
                    {story.value}
                  </span>
                </div>
                <p className="text-purple-700/90 text-xs font-semibold leading-normal flex-grow line-clamp-3 hover:line-clamp-none transition-all duration-300 cursor-pointer" title={story.summary}>{story.summary}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
