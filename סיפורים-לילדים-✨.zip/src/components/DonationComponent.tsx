import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Heart, Sparkles, Copy, Check, ExternalLink, X, Gift, Award, Star } from "lucide-react";

interface ReceiptData {
  name: string;
  amount: number;
  message: string;
  blessing: string;
}

export function DonationComponent() {
  const [paymentMethod, setPaymentMethod] = useState<"paypal" | "bit">("paypal");
  const [donationAmount, setDonationAmount] = useState<number | "custom">(36);
  const [customDonation, setCustomDonation] = useState("");
  const [donorName, setDonorName] = useState("");
  const [donorDedication, setDonorDedication] = useState("");
  
  // Popup & Blessing states
  const [showBlessingPopup, setShowBlessingPopup] = useState(false);
  const [receiptData, setReceiptData] = useState<ReceiptData | null>(null);
  const [copiedPhone, setCopiedPhone] = useState(false);

  const handleCopyPhone = () => {
    navigator.clipboard.writeText("053-426-2621");
    setCopiedPhone(true);
    setTimeout(() => setCopiedPhone(false), 2000);
  };

  const handleDonationSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Determine final amount
    const finalAmount = donationAmount === "custom" 
      ? parseFloat(customDonation) || 18 
      : donationAmount;
    
    if (finalAmount <= 0) return;

    // Traditional blessings list
    const customBlessings = [
      `יהי רצון מלפני אבינו שבשמיים שימלא כל משאלות ליבך לטובה, ותזכה לשפע עצום, פרנסה מבורכת ובריאות איתנה, בזכות נדיבות ליבך הטהור וצדקתך המאירה.`,
      `בזכות מצוות הצדקה ונדיבות ליבך, יתברכו כל מעשי ידיך, ותזכה להצליח בכל אשר תפנה, לראות בנים ובני בנים עוסקים בתורה ובמצוות, מתוך שפע, נחת ושלוות נפש.`,
      `תודה רבה על חיזוק מפעל השמות הקדושים והסיפורים לילדים. תזכה לחיים ארוכים וטובים, סיעתא דשמייא בכל העניינים וברכת שמים המלווה אותך בכל צעד ושעל.`
    ];
    
    const randomBlessing = customBlessings[Math.floor(Math.random() * customBlessings.length)];
    
    // Save details to display blessing document
    setReceiptData({
      name: donorName.trim() || "נדיב/ה אנונימי/ת",
      amount: finalAmount,
      message: donorDedication.trim(),
      blessing: randomBlessing
    });
    
    setShowBlessingPopup(true);

    // If PayPal, redirect to checkout
    if (paymentMethod === "paypal") {
      const paypalEmail = "ecomedia26@gmail.com";
      const itemName = `סוד השמות - תרומה והקדשה מאת ${donorName.trim() || "נדיב אנונימי"}`;
      const paypalUrl = `https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=${encodeURIComponent(paypalEmail)}&currency_code=ILS&amount=${finalAmount}&item_name=${encodeURIComponent(itemName)}`;
      
      window.open(paypalUrl, "_blank");
    }

    // Reset form fields
    setDonorName("");
    setDonorDedication("");
    setCustomDonation("");
  };

  return (
    <div className="w-full max-w-3xl mx-auto my-12 relative">
      {/* Glow Effects */}
      <div className="absolute -inset-1 bg-gradient-to-r from-amber-400 via-purple-500 to-pink-500 rounded-[2.6rem] blur opacity-25" />
      
      <div className="relative w-full bg-white border-2 border-amber-200 rounded-[2.5rem] p-6 sm:p-10 text-right shadow-xl shadow-amber-100/40" dir="rtl">
        
        <div className="text-center mb-8">
          <span className="inline-flex items-center justify-center p-3 bg-amber-50 rounded-2xl text-amber-600 mb-3 animate-bounce">
            <Heart className="w-8 h-8 fill-current" />
          </span>
          <h2 className="text-3xl font-black text-purple-950">
            נדיבות הלב והצדקה שלך ❤️
          </h2>
          <p className="text-purple-800/80 text-sm mt-2 max-w-lg mx-auto font-medium">
            "וּצְדָקָה תַּצִּיל מִמָּוֶת" • תרומתך מסייעת לנו להחזיק, לפתח ולהנגיש את אתר סיפורי הילדים והשמות לרווחת הכלל.
          </p>
        </div>

        {/* Payment Method Switcher Tabs */}
        <div className="flex bg-purple-50/80 p-1.5 rounded-2xl border border-purple-100/50 mb-8 max-w-md mx-auto">
          <button
            type="button"
            onClick={() => setPaymentMethod("paypal")}
            className={`flex-1 py-3 rounded-xl font-black text-sm transition-all cursor-pointer ${
              paymentMethod === "paypal" 
                ? "bg-gradient-to-r from-amber-500 to-amber-600 text-white shadow-md shadow-amber-200" 
                : "text-purple-850 hover:text-purple-900"
            }`}
          >
            💳 תרומה באשראי / PayPal
          </button>
          <button
            type="button"
            onClick={() => setPaymentMethod("bit")}
            className={`flex-1 py-3 rounded-xl font-black text-sm transition-all cursor-pointer ${
              paymentMethod === "bit" 
                ? "bg-gradient-to-r from-pink-500 to-rose-600 text-white shadow-md shadow-pink-200" 
                : "text-purple-850 hover:text-purple-950"
            }`}
          >
            📱 אפליקציית ביט (bit)
          </button>
        </div>

        {paymentMethod === "paypal" ? (
          <form onSubmit={handleDonationSubmit} className="space-y-6">
            {/* Fixed Amounts Selector */}
            <div>
              <label className="text-sm text-purple-900 font-bold block mb-3">בחר סכום תרומה (₪):</label>
              <div className="grid grid-cols-2 sm:grid-cols-6 gap-3">
                {[18, 36, 72, 180, 360].map((amount) => (
                  <button
                    type="button"
                    key={amount}
                    onClick={() => {
                      setDonationAmount(amount);
                      setCustomDonation("");
                    }}
                    className={`py-3.5 rounded-xl font-bold text-sm border-2 transition-all cursor-pointer ${
                      donationAmount === amount 
                        ? "bg-amber-50 border-amber-500 text-amber-700 shadow-sm" 
                        : "bg-white border-purple-100 hover:border-purple-200 text-purple-800"
                    }`}
                  >
                    {amount} ₪
                  </button>
                ))}
                
                <button
                  type="button"
                  onClick={() => setDonationAmount("custom")}
                  className={`py-3.5 rounded-xl font-bold text-sm border-2 transition-all cursor-pointer ${
                    donationAmount === "custom" 
                      ? "bg-amber-50 border-amber-500 text-amber-700 shadow-sm" 
                      : "bg-white border-purple-100 hover:border-purple-200 text-purple-850"
                  }`}
                >
                  סכום אחר
                </button>
              </div>
            </div>

            {/* Custom Amount Entry */}
            {donationAmount === "custom" && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-amber-50/50 p-4 rounded-2xl border border-amber-200"
              >
                <label className="text-xs text-purple-950 font-bold block mb-2">הזן סכום תרומה בשקלים (₪):</label>
                <input
                  type="number"
                  min="5"
                  value={customDonation}
                  onChange={(e) => setCustomDonation(e.target.value)}
                  placeholder="למשל: 100"
                  className="w-full bg-white border-2 border-purple-100 rounded-xl py-3 px-4 text-purple-950 text-right outline-none focus:border-amber-400 font-bold"
                  required
                />
              </motion.div>
            )}

            {/* Donor Dedication & Information */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs text-purple-900 font-black block mb-2">שם להקדשה וברכה:</label>
                <input
                  type="text"
                  value={donorName}
                  onChange={(e) => setDonorName(e.target.value)}
                  placeholder="למשל: משה בן שרה..."
                  className="w-full bg-white border-2 border-purple-100 rounded-xl py-3 px-4 text-purple-950 text-right outline-none focus:border-purple-300 font-medium"
                />
              </div>
              <div>
                <label className="text-xs text-purple-900 font-black block mb-2">בקשה רוחנית או תפילה:</label>
                <input
                  type="text"
                  value={donorDedication}
                  onChange={(e) => setDonorDedication(e.target.value)}
                  placeholder="למשל: לבריאות, זיווג הגון, זרע של קיימא..."
                  className="w-full bg-white border-2 border-purple-100 rounded-xl py-3 px-4 text-purple-950 text-right outline-none focus:border-purple-300 font-medium"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-gradient-to-r from-amber-500 via-amber-600 to-yellow-500 text-amber-950 font-black py-4.5 rounded-2xl transition-all hover:scale-[1.01] active:scale-[0.99] shadow-md shadow-amber-200/50 text-lg flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>מעבר מאובטח לתרומה והקדשה ב-PayPal</span>
              <ExternalLink className="w-5 h-5" />
            </button>
          </form>
        ) : (
          /* Bit payment form */
          <div className="space-y-6">
            <div className="p-5 bg-gradient-to-r from-pink-500/10 to-transparent border border-pink-500/20 rounded-3xl flex flex-col sm:flex-row items-center justify-between gap-4">
              <div>
                <h4 className="text-base font-black text-purple-950 mb-1">תרומה מהירה באפליקציית ביט (bit)</h4>
                <p className="text-xs text-purple-800/80 font-medium">שלחו ישירות למספר הטלפון של המיזם:</p>
              </div>
              <div className="flex items-center gap-2 bg-white border-2 border-pink-200 rounded-2xl py-2.5 px-4 shadow-sm">
                <span className="text-lg font-mono font-black text-pink-600">053-426-2621</span>
                <button
                  type="button"
                  onClick={handleCopyPhone}
                  className="p-1.5 hover:bg-pink-50 text-pink-500 rounded-lg transition-all cursor-pointer"
                  title="העתק מספר טלפון"
                >
                  {copiedPhone ? (
                    <Check className="w-5 h-5 text-green-600" />
                  ) : (
                    <Copy className="w-5 h-5" />
                  )}
                </button>
              </div>
            </div>
            
            <div className="p-5 bg-purple-50/60 border border-purple-100 rounded-2xl text-sm text-purple-900 leading-relaxed space-y-2">
              <strong className="text-purple-950 text-base block">כיצד לתרום בביט?</strong>
              <div className="space-y-1 font-medium text-purple-850">
                <p>1. העתיקו את מספר הטלפון למעלה.</p>
                <p>2. פתחו את אפליקציית bit בנייד והעבירו את הסכום המבוקש.</p>
                <p>3. לאחר מכן, אתם מוזמנים למלא את הטופס למטה לקבלת הברכה האישית על המסך!</p>
              </div>
            </div>

            {/* Quick Dedication for Bit Donors to get Blessing Document */}
            <form onSubmit={handleDonationSubmit} className="space-y-4 pt-4 border-t border-purple-100/50">
              <h4 className="font-black text-purple-950">קבלת ברכה והקדשה אישית:</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-purple-900 font-bold block mb-1">שם להקדשה וברכה:</label>
                  <input
                    type="text"
                    value={donorName}
                    onChange={(e) => setDonorName(e.target.value)}
                    placeholder="משה בן שרה..."
                    className="w-full bg-white border-2 border-purple-100 rounded-xl py-2.5 px-4 text-purple-950 text-right outline-none focus:border-purple-300"
                  />
                </div>
                <div>
                  <label className="text-xs text-purple-900 font-bold block mb-1">בקשה רוחנית או תפילה:</label>
                  <input
                    type="text"
                    value={donorDedication}
                    onChange={(e) => setDonorDedication(e.target.value)}
                    placeholder="למשל: לבריאות, זיווג הגון..."
                    className="w-full bg-white border-2 border-purple-100 rounded-xl py-2.5 px-4 text-purple-950 text-right outline-none focus:border-purple-300"
                  />
                </div>
              </div>
              <button
                type="submit"
                className="w-full bg-pink-500 hover:bg-pink-600 text-white font-black py-4 rounded-xl transition-all cursor-pointer shadow-md shadow-pink-100"
              >
                שלח הקדשה וקבל שטר ברכה אישי ✨
              </button>
            </form>
          </div>
        )}
      </div>

      {/* BLESSING popup MODAL */}
      <AnimatePresence>
        {showBlessingPopup && receiptData && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/65 backdrop-blur-sm" dir="rtl">
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative w-full max-w-xl bg-gradient-to-b from-[#fdfbf7] to-[#f5ebd6] border-4 border-amber-400 p-8 sm:p-12 rounded-[2.5rem] shadow-2xl overflow-hidden text-center"
            >
              {/* Confetti details */}
              <div className="absolute top-0 inset-x-0 h-2 bg-gradient-to-r from-amber-300 via-yellow-400 to-amber-500" />
              <div className="absolute -left-16 -top-16 w-36 h-36 bg-amber-200/20 rounded-full blur-2xl" />
              <div className="absolute -right-16 -bottom-16 w-36 h-36 bg-amber-200/20 rounded-full blur-2xl" />

              {/* Close Button */}
              <button
                onClick={() => setShowBlessingPopup(false)}
                className="absolute top-4 left-4 p-2 bg-amber-100 hover:bg-amber-200 text-amber-800 rounded-full transition-all cursor-pointer"
                title="סגור"
              >
                <X className="w-5 h-5" />
              </button>

              {/* Header Certificate */}
              <div className="mb-6">
                <span className="inline-flex items-center justify-center p-3.5 bg-amber-100 text-amber-700 rounded-full mb-4">
                  <Award className="w-10 h-10" />
                </span>
                <h3 className="text-2xl sm:text-3xl font-serif font-black text-amber-900 leading-snug">
                  שטר ברכה והקדשה קדוש 📜
                </h3>
                <div className="h-[2px] w-24 bg-amber-400 mx-auto mt-3 rounded-full" />
              </div>

              {/* Main Content Blessing */}
              <div className="space-y-6 text-amber-950">
                <p className="text-lg font-serif font-bold">
                  "טוֹב עַיִן הוּא יְבֹרָךְ כִּי נָתַן מִלַּחְמוֹ לַדָּל"
                </p>

                <div className="bg-white/80 border border-amber-200/60 p-6 rounded-2xl shadow-inner space-y-4 text-right">
                  <p className="text-sm text-amber-800 font-bold">
                    מתוך הכרת הטוב והערכה עמוקה על תרומה בסך: <span className="text-lg font-black text-amber-900">{receiptData.amount} ₪</span>
                  </p>
                  
                  <p className="text-sm text-amber-800 font-bold border-t border-amber-100 pt-3">
                    הקדשה וברכה עבור: <span className="text-base font-black text-amber-900">{receiptData.name}</span>
                  </p>

                  {receiptData.message && (
                    <p className="text-xs text-amber-700 font-bold">
                      תפילה מיוחדת עבור: <span className="italic text-amber-900">"{receiptData.message}"</span>
                    </p>
                  )}
                </div>

                <div className="py-2 px-4 rounded-xl border border-dashed border-amber-300 bg-amber-50/50">
                  <p className="text-base sm:text-lg text-amber-900 leading-relaxed font-serif font-medium whitespace-pre-line">
                    {receiptData.blessing}
                  </p>
                </div>

                <p className="text-xs text-amber-700 font-bold">
                  הברכה והצדקה נרשמו בשמי מרומים למזל, ברכה והצלחה בכל מעשה ידיכם!
                </p>
              </div>

              {/* Footer Certificate decoration */}
              <div className="mt-8 flex justify-center gap-3">
                <button
                  onClick={() => setShowBlessingPopup(false)}
                  className="px-8 py-3 bg-gradient-to-r from-amber-700 to-amber-900 hover:from-amber-800 hover:to-amber-950 text-white font-black rounded-xl shadow-md transition-all cursor-pointer"
                >
                  אמן, תודה רבה! 🙏
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
